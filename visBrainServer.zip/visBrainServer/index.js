var express = require('express')
var app = express();
var tempimageArray = [];
app.post('/image', function (req, res) {
    try {
        if (req.body.DeviceID && req.body.userName && req.bosy.imageBase) {
            try {
                tempimageArray.push({
                    DeviceID: req.body.DeviceID,
                    userName: req.body.userName,
                    imageBase: req.body.imageBase
                });
            }
            catch (e) {
                console.log('Error in pushing element ' + e)
            }
            res.send('Iamge Saved');
        }
        else {
            res.send('Error In request')
        }
    }
    catch (e) {
        console.log('Error In Post Request' + e);

    }
});
app.listen(3000)